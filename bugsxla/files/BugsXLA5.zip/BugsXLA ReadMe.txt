BugsXLA
(Version 5.0)
**********************************************************************
Provides a user friendly interface for Bayesian analysis using WinBUGS.

A toolbar will be created with the following functionality:

Export to WinBUGS
---------------------
Simplifies creation of WinBUGS ready data files from data already in Excel.

Edit WinBUGS Script
-----------------------
Starts Notepad, with optional user provided Script Template or with instructions for importing data previously exported from Excel, so that a WinBUGS script can be created.

Run WinBUGS (Script)
------------------------
Starts WinBUGS, optionally automatically running a specified script.

Import from WinBUGS
------------------------
Imports WinBUGS results into Excel.

Bayesian Model
-------------------
Allows the user to specify a Hierarchical Generalised Linear Model, and some more complex models, for Bayesian analysis using WinBUGS.

Post Plots
-------------------
Produces a histogram from posterior samples exported from WinBUGS, adding Prior Distribution when this can be inferred.  Can also be used to plot histogram of any column of data, with optional distribution overlayed.

BugsXLA Options
--------------------
Allows the user to set various general options.

Help is available for each form by checking the help box, and then moving the mouse over any highlighted areas.