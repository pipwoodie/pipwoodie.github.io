BugsXLA
(Version 7.02)
****************************************************************************************************************************
Recommended that BugsXLA files be extracted to folder: c:\BugsXLA7
BugsXLA7.xla should then be Add-In to Excel (refer to MS Office support for instructions relevant to your version of Excel)
****************************************************************************************************************************
Provides a user friendly interface for Bayesian analysis using BUGS (Open/Win) or JAGS.

A toolbar will be created with the following functionality:

Export to BUGS
---------------------
Simplifies creation of BUGS ready data files from data already in Excel.

Edit BUGS Script
-----------------------
Starts Notepad, with optional user provided Script Template or with instructions for importing data previously exported from Excel, so that a BUGS script can be created.

Run BUGS/JAGS (Script)
------------------------
Starts BUGS or JAGS, optionally automatically running a specified script.

Import from BUGS
------------------------
Imports BUGS results into Excel.

Bayesian Model
-------------------
Allows the user to specify a Hierarchical Generalised Linear Model, and some more complex models, for Bayesian analysis using BUGS or JAGS.

Post Plots
-------------------
Produces a histogram from posterior samples exported from BUGS or JAGS, adding Prior Distribution when this can be inferred.
Can also be used to plot histogram of any column of data, with optional distribution overlayed.
Can produce plots from the predictions and contrasts imported using BugsXLA's Bayesian Model specification tool.
Can also be used to alter the credible limits in table of summaries.

BugsXLA Options
--------------------
Allows the user to set various general options.

Help is available for each form by checking the help box, and then moving the mouse over any highlighted areas.